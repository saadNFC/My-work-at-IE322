﻿namespace lesson_1
{
    partial class frm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BoxLogin = new System.Windows.Forms.GroupBox();
            this.TextPass = new System.Windows.Forms.TextBox();
            this.TextUse = new System.Windows.Forms.TextBox();
            this.TextPassword = new System.Windows.Forms.Label();
            this.TextUsername = new System.Windows.Forms.Label();
            this.BtnLogin = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnAbout = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.BoxDraw = new System.Windows.Forms.GroupBox();
            this.BtnTalk = new System.Windows.Forms.Button();
            this.BtnDraw = new System.Windows.Forms.Button();
            this.BoxControls = new System.Windows.Forms.GroupBox();
            this.BtnTimer = new System.Windows.Forms.Button();
            this.BtnCom = new System.Windows.Forms.Button();
            this.BtnRandom = new System.Windows.Forms.Button();
            this.BtnProgress = new System.Windows.Forms.Button();
            this.BoxMaicro = new System.Windows.Forms.GroupBox();
            this.BtnArd = new System.Windows.Forms.Button();
            this.BoxExam = new System.Windows.Forms.GroupBox();
            this.BtnMnc = new System.Windows.Forms.Button();
            this.BtnJohari = new System.Windows.Forms.Button();
            this.BtnABC = new System.Windows.Forms.Button();
            this.BtnRobotic = new System.Windows.Forms.Button();
            this.BoxGraphical = new System.Windows.Forms.GroupBox();
            this.BtnPicture = new System.Windows.Forms.Button();
            this.BtnPicture2 = new System.Windows.Forms.Button();
            this.BtnSelfie = new System.Windows.Forms.Button();
            this.BtnGroupie = new System.Windows.Forms.Button();
            this.BoxBasic = new System.Windows.Forms.GroupBox();
            this.BtnCombo = new System.Windows.Forms.Button();
            this.BtnCheckBox = new System.Windows.Forms.Button();
            this.BtnRadio = new System.Windows.Forms.Button();
            this.BtnArrays = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BtnClass = new System.Windows.Forms.Button();
            this.BtnMethod = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BoxLogin.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.BoxDraw.SuspendLayout();
            this.BoxControls.SuspendLayout();
            this.BoxMaicro.SuspendLayout();
            this.BoxExam.SuspendLayout();
            this.BoxGraphical.SuspendLayout();
            this.BoxBasic.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // BoxLogin
            // 
            this.BoxLogin.BackColor = System.Drawing.Color.Transparent;
            this.BoxLogin.Controls.Add(this.TextPass);
            this.BoxLogin.Controls.Add(this.TextUse);
            this.BoxLogin.Controls.Add(this.TextPassword);
            this.BoxLogin.Controls.Add(this.TextUsername);
            this.BoxLogin.Controls.Add(this.BtnLogin);
            this.BoxLogin.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxLogin.ForeColor = System.Drawing.Color.Navy;
            this.BoxLogin.Location = new System.Drawing.Point(12, 24);
            this.BoxLogin.Name = "BoxLogin";
            this.BoxLogin.Size = new System.Drawing.Size(217, 169);
            this.BoxLogin.TabIndex = 0;
            this.BoxLogin.TabStop = false;
            this.BoxLogin.Text = "Login to IE322";
            // 
            // TextPass
            // 
            this.TextPass.Location = new System.Drawing.Point(75, 80);
            this.TextPass.Name = "TextPass";
            this.TextPass.Size = new System.Drawing.Size(100, 22);
            this.TextPass.TabIndex = 4;
            // 
            // TextUse
            // 
            this.TextUse.Location = new System.Drawing.Point(75, 32);
            this.TextUse.Name = "TextUse";
            this.TextUse.Size = new System.Drawing.Size(100, 22);
            this.TextUse.TabIndex = 3;
            this.TextUse.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TextPassword
            // 
            this.TextPassword.AutoSize = true;
            this.TextPassword.Location = new System.Drawing.Point(10, 83);
            this.TextPassword.Name = "TextPassword";
            this.TextPassword.Size = new System.Drawing.Size(59, 15);
            this.TextPassword.TabIndex = 2;
            this.TextPassword.Text = "Password";
            // 
            // TextUsername
            // 
            this.TextUsername.AutoSize = true;
            this.TextUsername.Location = new System.Drawing.Point(9, 32);
            this.TextUsername.Name = "TextUsername";
            this.TextUsername.Size = new System.Drawing.Size(60, 15);
            this.TextUsername.TabIndex = 1;
            this.TextUsername.Text = "Username";
            // 
            // BtnLogin
            // 
            this.BtnLogin.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BtnLogin.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLogin.Location = new System.Drawing.Point(51, 121);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.Size = new System.Drawing.Size(105, 39);
            this.BtnLogin.TabIndex = 0;
            this.BtnLogin.Text = "Login";
            this.BtnLogin.UseVisualStyleBackColor = false;
            this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnAbout);
            this.groupBox1.Controls.Add(this.BtnExit);
            this.groupBox1.Controls.Add(this.BoxDraw);
            this.groupBox1.Controls.Add(this.BoxControls);
            this.groupBox1.Controls.Add(this.BoxMaicro);
            this.groupBox1.Controls.Add(this.BoxExam);
            this.groupBox1.Controls.Add(this.BoxGraphical);
            this.groupBox1.Controls.Add(this.BoxBasic);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(235, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(420, 418);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // BtnAbout
            // 
            this.BtnAbout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BtnAbout.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAbout.ForeColor = System.Drawing.Color.Navy;
            this.BtnAbout.Location = new System.Drawing.Point(6, 363);
            this.BtnAbout.Name = "BtnAbout";
            this.BtnAbout.Size = new System.Drawing.Size(73, 44);
            this.BtnAbout.TabIndex = 2;
            this.BtnAbout.Text = "About";
            this.BtnAbout.UseVisualStyleBackColor = false;
            this.BtnAbout.Click += new System.EventHandler(this.BtnAbout_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.Gold;
            this.BtnExit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.ForeColor = System.Drawing.Color.Navy;
            this.BtnExit.Location = new System.Drawing.Point(85, 363);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(329, 44);
            this.BtnExit.TabIndex = 3;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BoxDraw
            // 
            this.BoxDraw.BackColor = System.Drawing.Color.Transparent;
            this.BoxDraw.Controls.Add(this.BtnTalk);
            this.BoxDraw.Controls.Add(this.BtnDraw);
            this.BoxDraw.ForeColor = System.Drawing.Color.Navy;
            this.BoxDraw.Location = new System.Drawing.Point(213, 249);
            this.BoxDraw.Name = "BoxDraw";
            this.BoxDraw.Size = new System.Drawing.Size(201, 108);
            this.BoxDraw.TabIndex = 2;
            this.BoxDraw.TabStop = false;
            this.BoxDraw.Text = "Draw and Talk";
            // 
            // BtnTalk
            // 
            this.BtnTalk.Location = new System.Drawing.Point(98, 42);
            this.BtnTalk.Name = "BtnTalk";
            this.BtnTalk.Size = new System.Drawing.Size(83, 25);
            this.BtnTalk.TabIndex = 2;
            this.BtnTalk.Text = "Talk";
            this.BtnTalk.UseVisualStyleBackColor = true;
            // 
            // BtnDraw
            // 
            this.BtnDraw.Font = new System.Drawing.Font("Tahoma", 8F);
            this.BtnDraw.ForeColor = System.Drawing.Color.Navy;
            this.BtnDraw.Location = new System.Drawing.Point(6, 42);
            this.BtnDraw.Name = "BtnDraw";
            this.BtnDraw.Size = new System.Drawing.Size(86, 25);
            this.BtnDraw.TabIndex = 1;
            this.BtnDraw.Text = "Draw";
            this.BtnDraw.UseVisualStyleBackColor = true;
            // 
            // BoxControls
            // 
            this.BoxControls.BackColor = System.Drawing.Color.Transparent;
            this.BoxControls.Controls.Add(this.BtnTimer);
            this.BoxControls.Controls.Add(this.BtnCom);
            this.BoxControls.Controls.Add(this.BtnRandom);
            this.BoxControls.Controls.Add(this.BtnProgress);
            this.BoxControls.ForeColor = System.Drawing.Color.Navy;
            this.BoxControls.Location = new System.Drawing.Point(6, 249);
            this.BoxControls.Name = "BoxControls";
            this.BoxControls.Size = new System.Drawing.Size(201, 108);
            this.BoxControls.TabIndex = 1;
            this.BoxControls.TabStop = false;
            this.BoxControls.Text = "More Controls";
            this.BoxControls.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // BtnTimer
            // 
            this.BtnTimer.Location = new System.Drawing.Point(108, 28);
            this.BtnTimer.Name = "BtnTimer";
            this.BtnTimer.Size = new System.Drawing.Size(75, 25);
            this.BtnTimer.TabIndex = 4;
            this.BtnTimer.Text = "Timer";
            this.BtnTimer.UseVisualStyleBackColor = true;
            // 
            // BtnCom
            // 
            this.BtnCom.Location = new System.Drawing.Point(108, 75);
            this.BtnCom.Name = "BtnCom";
            this.BtnCom.Size = new System.Drawing.Size(75, 25);
            this.BtnCom.TabIndex = 3;
            this.BtnCom.Text = "RandomCom";
            this.BtnCom.UseVisualStyleBackColor = true;
            this.BtnCom.Click += new System.EventHandler(this.BtnCom_Click_1);
            // 
            // BtnRandom
            // 
            this.BtnRandom.Location = new System.Drawing.Point(15, 75);
            this.BtnRandom.Name = "BtnRandom";
            this.BtnRandom.Size = new System.Drawing.Size(75, 25);
            this.BtnRandom.TabIndex = 2;
            this.BtnRandom.Text = "Random";
            this.BtnRandom.UseVisualStyleBackColor = true;
            this.BtnRandom.Click += new System.EventHandler(this.BtnRandom_Click);
            // 
            // BtnProgress
            // 
            this.BtnProgress.Location = new System.Drawing.Point(15, 28);
            this.BtnProgress.Name = "BtnProgress";
            this.BtnProgress.Size = new System.Drawing.Size(75, 25);
            this.BtnProgress.TabIndex = 1;
            this.BtnProgress.Text = "Progress";
            this.BtnProgress.UseVisualStyleBackColor = true;
            // 
            // BoxMaicro
            // 
            this.BoxMaicro.BackColor = System.Drawing.Color.Transparent;
            this.BoxMaicro.Controls.Add(this.BtnArd);
            this.BoxMaicro.ForeColor = System.Drawing.Color.Navy;
            this.BoxMaicro.Location = new System.Drawing.Point(213, 177);
            this.BoxMaicro.Name = "BoxMaicro";
            this.BoxMaicro.Size = new System.Drawing.Size(201, 67);
            this.BoxMaicro.TabIndex = 1;
            this.BoxMaicro.TabStop = false;
            this.BoxMaicro.Text = "Micro Conroller";
            // 
            // BtnArd
            // 
            this.BtnArd.Location = new System.Drawing.Point(15, 27);
            this.BtnArd.Name = "BtnArd";
            this.BtnArd.Size = new System.Drawing.Size(166, 25);
            this.BtnArd.TabIndex = 1;
            this.BtnArd.Text = "Arduino";
            this.BtnArd.UseVisualStyleBackColor = true;
            // 
            // BoxExam
            // 
            this.BoxExam.BackColor = System.Drawing.Color.Transparent;
            this.BoxExam.Controls.Add(this.BtnMnc);
            this.BoxExam.Controls.Add(this.BtnJohari);
            this.BoxExam.Controls.Add(this.BtnABC);
            this.BoxExam.Controls.Add(this.BtnRobotic);
            this.BoxExam.ForeColor = System.Drawing.Color.Navy;
            this.BoxExam.Location = new System.Drawing.Point(213, 19);
            this.BoxExam.Name = "BoxExam";
            this.BoxExam.Size = new System.Drawing.Size(201, 150);
            this.BoxExam.TabIndex = 1;
            this.BoxExam.TabStop = false;
            this.BoxExam.Text = "Exam Apps";
            // 
            // BtnMnc
            // 
            this.BtnMnc.Location = new System.Drawing.Point(26, 19);
            this.BtnMnc.Name = "BtnMnc";
            this.BtnMnc.Size = new System.Drawing.Size(132, 25);
            this.BtnMnc.TabIndex = 4;
            this.BtnMnc.Text = "Manufacturing Cell";
            this.BtnMnc.UseVisualStyleBackColor = true;
            // 
            // BtnJohari
            // 
            this.BtnJohari.Location = new System.Drawing.Point(27, 116);
            this.BtnJohari.Name = "BtnJohari";
            this.BtnJohari.Size = new System.Drawing.Size(132, 25);
            this.BtnJohari.TabIndex = 3;
            this.BtnJohari.Text = "Johri";
            this.BtnJohari.UseVisualStyleBackColor = true;
            this.BtnJohari.Click += new System.EventHandler(this.button6_Click);
            // 
            // BtnABC
            // 
            this.BtnABC.Location = new System.Drawing.Point(27, 52);
            this.BtnABC.Name = "BtnABC";
            this.BtnABC.Size = new System.Drawing.Size(132, 25);
            this.BtnABC.TabIndex = 2;
            this.BtnABC.Text = "ABC Analysis";
            this.BtnABC.UseVisualStyleBackColor = true;
            // 
            // BtnRobotic
            // 
            this.BtnRobotic.Location = new System.Drawing.Point(26, 83);
            this.BtnRobotic.Name = "BtnRobotic";
            this.BtnRobotic.Size = new System.Drawing.Size(133, 25);
            this.BtnRobotic.TabIndex = 1;
            this.BtnRobotic.Text = "Robotic Cell";
            this.BtnRobotic.UseVisualStyleBackColor = true;
            // 
            // BoxGraphical
            // 
            this.BoxGraphical.BackColor = System.Drawing.Color.Transparent;
            this.BoxGraphical.Controls.Add(this.BtnPicture);
            this.BoxGraphical.Controls.Add(this.BtnPicture2);
            this.BoxGraphical.Controls.Add(this.BtnSelfie);
            this.BoxGraphical.Controls.Add(this.BtnGroupie);
            this.BoxGraphical.ForeColor = System.Drawing.Color.Navy;
            this.BoxGraphical.Location = new System.Drawing.Point(6, 133);
            this.BoxGraphical.Name = "BoxGraphical";
            this.BoxGraphical.Size = new System.Drawing.Size(201, 111);
            this.BoxGraphical.TabIndex = 1;
            this.BoxGraphical.TabStop = false;
            this.BoxGraphical.Text = "Graphical";
            // 
            // BtnPicture
            // 
            this.BtnPicture.Location = new System.Drawing.Point(15, 37);
            this.BtnPicture.Name = "BtnPicture";
            this.BtnPicture.Size = new System.Drawing.Size(75, 25);
            this.BtnPicture.TabIndex = 4;
            this.BtnPicture.Text = "PictureBox";
            this.BtnPicture.UseVisualStyleBackColor = true;
            this.BtnPicture.Click += new System.EventHandler(this.BtnPicture_Click);
            // 
            // BtnPicture2
            // 
            this.BtnPicture2.Location = new System.Drawing.Point(15, 71);
            this.BtnPicture2.Name = "BtnPicture2";
            this.BtnPicture2.Size = new System.Drawing.Size(75, 25);
            this.BtnPicture2.TabIndex = 3;
            this.BtnPicture2.Text = "PictureBox2";
            this.BtnPicture2.UseVisualStyleBackColor = true;
            this.BtnPicture2.Click += new System.EventHandler(this.BtnPicture2_Click);
            // 
            // BtnSelfie
            // 
            this.BtnSelfie.Location = new System.Drawing.Point(108, 37);
            this.BtnSelfie.Name = "BtnSelfie";
            this.BtnSelfie.Size = new System.Drawing.Size(75, 25);
            this.BtnSelfie.TabIndex = 2;
            this.BtnSelfie.Text = "SelfieApp";
            this.BtnSelfie.UseVisualStyleBackColor = true;
            // 
            // BtnGroupie
            // 
            this.BtnGroupie.Location = new System.Drawing.Point(108, 71);
            this.BtnGroupie.Name = "BtnGroupie";
            this.BtnGroupie.Size = new System.Drawing.Size(75, 25);
            this.BtnGroupie.TabIndex = 1;
            this.BtnGroupie.Text = "Groupie App";
            this.BtnGroupie.UseVisualStyleBackColor = true;
            // 
            // BoxBasic
            // 
            this.BoxBasic.BackColor = System.Drawing.Color.Transparent;
            this.BoxBasic.Controls.Add(this.BtnCombo);
            this.BoxBasic.Controls.Add(this.BtnCheckBox);
            this.BoxBasic.Controls.Add(this.BtnRadio);
            this.BoxBasic.ForeColor = System.Drawing.Color.Navy;
            this.BoxBasic.Location = new System.Drawing.Point(6, 19);
            this.BoxBasic.Name = "BoxBasic";
            this.BoxBasic.Size = new System.Drawing.Size(201, 108);
            this.BoxBasic.TabIndex = 0;
            this.BoxBasic.TabStop = false;
            this.BoxBasic.Text = "Basic Controls";
            // 
            // BtnCombo
            // 
            this.BtnCombo.Location = new System.Drawing.Point(70, 65);
            this.BtnCombo.Name = "BtnCombo";
            this.BtnCombo.Size = new System.Drawing.Size(75, 25);
            this.BtnCombo.TabIndex = 2;
            this.BtnCombo.Text = "Combo";
            this.BtnCombo.UseVisualStyleBackColor = true;
            this.BtnCombo.Click += new System.EventHandler(this.BtnCombo_Click);
            // 
            // BtnCheckBox
            // 
            this.BtnCheckBox.Location = new System.Drawing.Point(108, 32);
            this.BtnCheckBox.Name = "BtnCheckBox";
            this.BtnCheckBox.Size = new System.Drawing.Size(75, 25);
            this.BtnCheckBox.TabIndex = 1;
            this.BtnCheckBox.Text = "CheckBox";
            this.BtnCheckBox.UseVisualStyleBackColor = true;
            this.BtnCheckBox.Click += new System.EventHandler(this.BtnCheckBox_Click);
            // 
            // BtnRadio
            // 
            this.BtnRadio.Location = new System.Drawing.Point(27, 32);
            this.BtnRadio.Name = "BtnRadio";
            this.BtnRadio.Size = new System.Drawing.Size(75, 25);
            this.BtnRadio.TabIndex = 0;
            this.BtnRadio.Text = "Radio";
            this.BtnRadio.UseVisualStyleBackColor = true;
            this.BtnRadio.Click += new System.EventHandler(this.BtnRadio_Click);
            // 
            // BtnArrays
            // 
            this.BtnArrays.ForeColor = System.Drawing.Color.MidnightBlue;
            this.BtnArrays.Location = new System.Drawing.Point(661, 24);
            this.BtnArrays.Name = "BtnArrays";
            this.BtnArrays.Size = new System.Drawing.Size(138, 171);
            this.BtnArrays.TabIndex = 7;
            this.BtnArrays.Text = "Arrays";
            this.BtnArrays.UseVisualStyleBackColor = true;
            this.BtnArrays.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BtnClass);
            this.groupBox2.Controls.Add(this.BtnMethod);
            this.groupBox2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.groupBox2.Location = new System.Drawing.Point(661, 201);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(138, 100);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Objrct Oriented";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // BtnClass
            // 
            this.BtnClass.ForeColor = System.Drawing.Color.MidnightBlue;
            this.BtnClass.Location = new System.Drawing.Point(12, 54);
            this.BtnClass.Name = "BtnClass";
            this.BtnClass.Size = new System.Drawing.Size(114, 26);
            this.BtnClass.TabIndex = 9;
            this.BtnClass.Text = "Classes";
            this.BtnClass.UseVisualStyleBackColor = true;
            // 
            // BtnMethod
            // 
            this.BtnMethod.ForeColor = System.Drawing.Color.MidnightBlue;
            this.BtnMethod.Location = new System.Drawing.Point(12, 22);
            this.BtnMethod.Name = "BtnMethod";
            this.BtnMethod.Size = new System.Drawing.Size(114, 26);
            this.BtnMethod.TabIndex = 8;
            this.BtnMethod.Text = "Methods";
            this.BtnMethod.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(715, 387);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Math";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(802, 460);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.BtnArrays);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BoxLogin);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.DarkRed;
            this.Name = "frm1";
            this.Text = "IE322_S20_KAU";
            this.Load += new System.EventHandler(this.frm1_Load);
            this.BoxLogin.ResumeLayout(false);
            this.BoxLogin.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.BoxDraw.ResumeLayout(false);
            this.BoxControls.ResumeLayout(false);
            this.BoxMaicro.ResumeLayout(false);
            this.BoxExam.ResumeLayout(false);
            this.BoxGraphical.ResumeLayout(false);
            this.BoxBasic.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox BoxLogin;
        private System.Windows.Forms.TextBox TextPass;
        private System.Windows.Forms.TextBox TextUse;
        private System.Windows.Forms.Label TextPassword;
        private System.Windows.Forms.Label TextUsername;
        private System.Windows.Forms.Button BtnLogin;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox BoxControls;
        private System.Windows.Forms.GroupBox BoxExam;
        private System.Windows.Forms.GroupBox BoxGraphical;
        private System.Windows.Forms.GroupBox BoxBasic;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.GroupBox BoxDraw;
        private System.Windows.Forms.Button BtnTalk;
        private System.Windows.Forms.Button BtnDraw;
        private System.Windows.Forms.Button BtnTimer;
        private System.Windows.Forms.Button BtnCom;
        private System.Windows.Forms.Button BtnRandom;
        private System.Windows.Forms.Button BtnProgress;
        private System.Windows.Forms.Button BtnArd;
        private System.Windows.Forms.Button BtnMnc;
        private System.Windows.Forms.Button BtnJohari;
        private System.Windows.Forms.Button BtnABC;
        private System.Windows.Forms.Button BtnRobotic;
        private System.Windows.Forms.Button BtnPicture;
        private System.Windows.Forms.Button BtnPicture2;
        private System.Windows.Forms.Button BtnSelfie;
        private System.Windows.Forms.Button BtnGroupie;
        private System.Windows.Forms.Button BtnCombo;
        private System.Windows.Forms.Button BtnCheckBox;
        private System.Windows.Forms.Button BtnRadio;
        private System.Windows.Forms.Button BtnAbout;
        public System.Windows.Forms.GroupBox BoxMaicro;
        private System.Windows.Forms.Button BtnArrays;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BtnClass;
        private System.Windows.Forms.Button BtnMethod;
        private System.Windows.Forms.Button button2;
    }
}

